//
//  DetailModel.swift
//  购物车
//
//  Created by 李森 on 2016/12/13.
//  Copyright © 2016年 李森. All rights reserved.
//

import UIKit

class DetailModel: NSObject {
    var id: String?
    var icon: String?
    var name: String?
    var originalPrice: String?
    var salePrice: String?
    var stock: String?
    var desc: String?
    
    init(data: JSON) {
        super.init()
        self.id = data["id"].stringValue
        self.icon = data["icon"].stringValue
        self.name = data["name"].stringValue
        self.originalPrice = data["originalPrice"].stringValue
        self.salePrice = data["salePrice"].stringValue
        self.stock = data["stock"].stringValue
        self.desc = data["desc"].stringValue
    }
    
    override init() {
        super.init()
    }
}
