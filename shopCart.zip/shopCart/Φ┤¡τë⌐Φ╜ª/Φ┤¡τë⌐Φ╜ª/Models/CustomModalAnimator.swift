//
//  CustomModalAnimator.swift
//  购物车
//
//  Created by BoBo on 17/3/9.
//  Copyright © 2017年 李森. All rights reserved.
//

import UIKit

//MARK: - Modal转场采用UIModalPresentationCustom模式
class CustomModalAnimator: NSObject, UIViewControllerAnimatedTransitioning {
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.5
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let containerView: UIView = transitionContext.containerView
        guard let fromVC: UIViewController = transitionContext.viewController(forKey: .from), let toVC: UIViewController = transitionContext.viewController(forKey: .to) else {
            return
        }
        
        let fromView:UIView = fromVC.view
        let toView: UIView = toVC.view
        let duration = transitionDuration(using: transitionContext)
        
        if toVC.isBeingPresented {
            containerView.addSubview(toView)
            
            let toViweWidth = containerView.frame.width * 2.0 / 3.0
            let toViewHeight = containerView.frame.height * 2.0 / 3.0
            toView.center = containerView.center
            toView.bounds = CGRect(x: 0.0, y: 0.0, width: 1, height: toViewHeight)
            UIView.animate(withDuration: duration, delay: 0, options: [.curveEaseInOut], animations: {
                toView.bounds = CGRect(x: 0.0, y: 0.0, width: toViweWidth, height: toViewHeight)
            }, completion: { (isFinished: Bool) in
                transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
            })
        }
        
        if toVC.isBeingDismissed {
            let fromViewHeight = fromView.frame.height
            UIView.animate(withDuration: duration, animations: { 
                fromView.bounds = CGRect(x: 0.0, y: 0.0, width: 1.0, height: fromViewHeight)
            }, completion: { (isFinished: Bool) in
                transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
            })
        }
    }
   
}
