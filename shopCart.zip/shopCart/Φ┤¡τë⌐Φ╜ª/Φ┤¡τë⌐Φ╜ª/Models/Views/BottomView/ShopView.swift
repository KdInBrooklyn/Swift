//
//  ShopView.swift
//  购物车
//
//  Created by 李森 on 2017/3/6.
//  Copyright © 2017年 李森. All rights reserved.
//

import UIKit

class ShopView: UIView {
    //MARK: - properties
    fileprivate lazy var ivShop: UIImageView = {
        let imageView: UIImageView = UIImageView(frame: CGRect.zero)
        imageView.image = UIImage(named: "gouwuche")
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        let gesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ShopView.eventShopImageDidClick(_:)))
        imageView.addGestureRecognizer(gesture)
        
        return imageView
    }()
    
    //MARK: - life cycle
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    //MARK: - event response
    func eventShopImageDidClick(_ gesture: UITapGestureRecognizer) {
        
    }
    
    //MARK: - private method
    fileprivate func initViews() {
        self.addSubview(ivShop)
        ivShop.snp.makeConstraints { (make: ConstraintMaker) in
            make.left.equalTo(self).offset(20.0)
            make.bottom.equalTo(self).offset(-10.0)
            make.width.height.equalTo(50.0)
        }
    }
}
