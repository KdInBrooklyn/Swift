//
//  ShopView.swift
//  购物车
//
//  Created by 李森 on 2017/3/6.
//  Copyright © 2017年 李森. All rights reserved.
//

import UIKit

class ShopView: UIView {
    //MARK: - properties
    fileprivate lazy var ivShop: UIImageView = {
        let imageView: UIImageView = UIImageView(frame: CGRect.zero)
        imageView.image = UIImage(named: "gouwuche")
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        let gesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ShopView.eventShopImageDidClick(_:)))
        imageView.addGestureRecognizer(gesture)
        
        return imageView
    }()
    
    //MARK: - life cycle
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    //MARK: - public fuction
    // 图片的缩放动画
    internal func animationWithIvShop() {
        let animation: CAKeyframeAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
        animation.values = [ NSValue.init(caTransform3D: CATransform3DMakeScale(1.0, 1.0, 1.0)), NSValue.init(caTransform3D: CATransform3DMakeScale(1.2, 1.2, 1.0)), NSValue.init(caTransform3D: CATransform3DMakeScale(1.0, 1.0, 1.0))]
        animation.duration = 0.5
        
        
        ivShop.layer.add(animation, forKey: nil)
    }
    
    // 圆点添加动画
    internal func addCirleLayer() {
        let circleLayer: CAShapeLayer = CAShapeLayer()
        circleLayer.path = UIBezierPath(ovalIn: CGRect(x: 42.0, y: 2.0, width: 15.0, height: 15.0)).cgPath
        circleLayer.fillColor = UIColor.purple.cgColor
        ivShop.layer.addSublayer(circleLayer)
    }
    
    //MARK: - event response
    func eventShopImageDidClick(_ gesture: UITapGestureRecognizer) {
        
    }
    
    func eventUserDidClickBottomView() {
        
    }
    
    //MARK: - private method
    fileprivate func initViews() {
        self.addSubview(ivShop)
        ivShop.snp.makeConstraints { (make: ConstraintMaker) in
            make.left.equalTo(self).offset(20.0)
            make.bottom.equalTo(self).offset(-10.0)
            make.width.height.equalTo(50.0)
        }
    }
}
