//
//  LeftTableViewCell.swift
//  购物车
//
//  Created by 李森 on 2016/12/12.
//  Copyright © 2016年 李森. All rights reserved.
//

import UIKit

class LeftTableViewCell: UITableViewCell {

    //MARK: private properties
    @IBOutlet weak var colorLabel: UILabel!
    @IBOutlet weak var categoryLabel: UILabel!
    
    //MARK: life cycle
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    //MARK: private method
    fileprivate func initViews() {
        
    }
}
