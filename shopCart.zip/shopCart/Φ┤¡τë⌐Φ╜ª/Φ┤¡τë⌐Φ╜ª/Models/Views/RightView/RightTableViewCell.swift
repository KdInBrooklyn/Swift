//
//  RightTableViewCell.swift
//  购物车
//
//  Created by 李森 on 2016/12/12.
//  Copyright © 2016年 李森. All rights reserved.
//

import UIKit

class RightTableViewCell: UITableViewCell {

    //MARK: propertiies
    @IBOutlet weak var iconImg: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var originalLabel: UILabel!
    @IBOutlet weak var saleLabel: UILabel!
    @IBOutlet weak var addButton: UIButton!
   
    var cellObject: DetailModel? {
        didSet {
            if let model = cellObject {
                if let icoName = model.icon {
                    iconImg.image = UIImage(named: icoName)
                }
                if let name = model.name {
                    nameLabel.text = name
                }
                if let original = model.originalPrice {
                    originalLabel.text = "原价\(original)"
                }
                if let sale = model.salePrice {
                    saleLabel.text = sale
                }
            }
        }
    }
    
    //MARK: - 贝塞尔曲线动画相关属性
    fileprivate lazy var pathAnimation: CABasicAnimation = {[unowned self] in
        let animation: CABasicAnimation = CABasicAnimation(keyPath: "path")
        animation.fromValue = self.startPoint
        animation.toValue = self.endPath
        animation.duration = 4.0
//        animation.color
        return animation
    }()
    
    fileprivate let startPoint: UIBezierPath = {
        let path: UIBezierPath = UIBezierPath(ovalIn: CGRect(x: 0.0, y: 0.0, width: 20.0, height: 20.0))
        
        return path
    }()
    
    fileprivate let endPath: UIBezierPath = {
        let path: UIBezierPath = UIBezierPath(rect: CGRect(x: 10.0, y: 10.0, width: 100.0, height: 100.0))
        return path
    }()
    
    //MARK: life cycle
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    //在返回cell的方法之后
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
    //MARK: event response
    @IBAction func eventAddButtonDidClicked(_ sender: Any) {
//        self.addButton.layer
        let shapeLayer: CAShapeLayer = CAShapeLayer()
        shapeLayer.path = self.startPoint.cgPath
        shapeLayer.fillColor = UIColor.green.cgColor
        self.addButton.layer.addSublayer(shapeLayer)
        
        
        let pathAnimation: CABasicAnimation = CABasicAnimation()
        pathAnimation.fromValue = self.startPoint
        pathAnimation.toValue = self.endPath
        pathAnimation.duration = 4.0
        self.layer.add(pathAnimation, forKey: nil)
    }
    
    //MARK: - fileprivate method
    fileprivate func addAnimation() {
        
    }
}
