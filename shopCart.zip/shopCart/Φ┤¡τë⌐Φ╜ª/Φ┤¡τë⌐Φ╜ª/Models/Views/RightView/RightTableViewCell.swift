//
//  RightTableViewCell.swift
//  购物车
//
//  Created by 李森 on 2016/12/12.
//  Copyright © 2016年 李森. All rights reserved.
//

import UIKit

@objc protocol RightTableViewCellDelegate
{
    func rightTableViewCellDidSelect(_ cell: RightTableViewCell, _ viewX: CGFloat, _ viewY: CGFloat)
}

class RightTableViewCell: UITableViewCell {

    //MARK: propertiies
    weak var delegate: RightTableViewCellDelegate?
    fileprivate var originX: CGFloat = 0.0  //添加按钮在屏幕中的X坐标
    fileprivate var originY: CGFloat = 0.0  //添加按钮在屏幕中的Y坐标
    @IBOutlet weak var iconImg: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var originalLabel: UILabel!
    @IBOutlet weak var saleLabel: UILabel!
    @IBOutlet weak var addButton: UIButton!
    var productCount: Int = 0
    
    var cellObject: DetailModel? {
        didSet {
            if let model = cellObject {
                if let icoName = model.icon {
                    iconImg.image = UIImage(named: icoName)
                }
                if let name = model.name {
                    nameLabel.text = name
                }
                if let original = model.originalPrice {
                    originalLabel.text = "原价\(original)"
                }
                if let sale = model.salePrice {
                    saleLabel.text = sale
                }
            }
        }
    }
    
    //MARK: - 贝塞尔曲线动画相关属性
//    fileprivate lazy var pathAnimation: CABasicAnimation = {[unowned self] in
//        let animation: CABasicAnimation = CABasicAnimation(keyPath: "path")
//        animation.fromValue = self.startPoint
//        animation.toValue = self.endPath
//        animation.duration = 4.0
////        animation.color
//        return animation
//    }()
    
    fileprivate let startPoint: UIBezierPath = {
        let path: UIBezierPath = UIBezierPath(ovalIn: CGRect(x: 5.0, y: 5.0, width: 10.0, height: 10.0))
        
        return path
    }()
    
    
    //MARK: life cycle
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    deinit {
        delegate = nil
    }
    
    //在返回cell的方法之后
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
    //MARK: event response
    @IBAction func eventAddButtonDidClicked(_ sender: UIButton) {
        let rectInCell: CGRect = sender.convert(sender.frame, from: self)
        let rectInWindow: CGRect = sender.convert(rectInCell, to: UIApplication.shared.keyWindow)
        
        originX = rectInWindow.origin.x
        originY = rectInWindow.origin.y
        guard let _ = delegate?.rightTableViewCellDidSelect(self, originX, originY) else {
            return
        }
        
//        let shapeLayer: CAShapeLayer = CAShapeLayer()
//        shapeLayer.path = self.startPoint.cgPath
//        shapeLayer.fillColor = UIColor.black.cgColor
//        
//        let animationPath: UIBezierPath = UIBezierPath()
//        animationPath.move(to: CGPoint(x: 0.0, y: 0.0))
//        animationPath.addQuadCurve(to: CGPoint.init(x: -originX, y: UIScreen.main.bounds.height - 60.0 - originY), controlPoint: CGPoint(x: -100.0, y: 50.0))
//
//        let pathAnimation: CAKeyframeAnimation = CAKeyframeAnimation(keyPath: "position")
//        pathAnimation.path = animationPath.cgPath
//        pathAnimation.duration = 2.0
//        pathAnimation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
//        
//        shapeLayer.add(pathAnimation, forKey: nil)
//        self.addButton.layer.addSublayer(shapeLayer)
    }
    
    //MARK: - fileprivate method
    fileprivate func addAnimation() {
        
    }
}
