//
//  FullScreenModalAnimator.swift
//  购物车
//
//  Created by BoBo on 17/3/10.
//  Copyright © 2017年 李森. All rights reserved.
//

import UIKit

//MARK: - Modal转场采用UIModalPresentationFullScreen模式
class FullScreenModalAnimator: NSObject, UIViewControllerAnimatedTransitioning {
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.5
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let containerView: UIView = transitionContext.containerView
        guard let fromVC: UIViewController = transitionContext.viewController(forKey: .from), let toVC: UIViewController = transitionContext.viewController(forKey: .to) else {
            return
        }
        
        let fromView: UIView = fromVC.view
        let toView: UIView = toVC.view
        toView.alpha = 0.0
        containerView.addSubview(toView)
        
        UIView.animate(withDuration: 0.2, animations: {
            toView.alpha = 1.0
        }) { (isFinished: Bool) in
            fromView.alpha = 0.0
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
        
    }
}
