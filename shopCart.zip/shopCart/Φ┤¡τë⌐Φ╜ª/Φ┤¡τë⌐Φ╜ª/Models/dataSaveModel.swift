//
//  dataSaveModel.swift
//  购物车
//
//  Created by BoBo on 17/3/10.
//  Copyright © 2017年 李森. All rights reserved.
//

import UIKit

class dataSaveModel: NSObject {
    // MARK: - properties
    fileprivate var dataBase: FMDatabase?
    //创建单例
    static let sharedInstance = dataSaveModel()
    fileprivate override init() {
        super.init()
    }
    
    //MARK: 根据文件路径创建数据库
    func creatDataBase() {
        //获得数据库文件的路径
        let docStr: NSString = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
        //在document文件夹下面创建文件
        let fileName: String = docStr.appendingPathComponent("product.sqlite")
//        let fileName: String = docStr.appending("product.sqlite")   //在docStr后面拼接字符串
        //获得数据库
        dataBase = FMDatabase(path: fileName)
        //创建表单
        if (dataBase?.open())! {
            let result: Bool = dataBase!.executeUpdate("CREATE TABLE IF NOT EXISTS product (name TEXT NOT NULL, originalPrice TEXT NOT NULL, count INTEGER DEFAULT 0)", withParameterDictionary: nil)
            if (result) {
                print("create table success")
                print(docStr)
            } else {
                print("create table failed")
            }
        } else {
            print("open failed")
        }
    }
    
    //向数据库中添加数据
    func addProductToDataBase(_ productName: String, _ productPrice: String, productCount: Int) {
        let sql: String = "INSERT INTO product (name, originalPrice, count) VALUES (?, ?, ?)"
        let result: Bool = dataBase!.executeUpdate(sql, withArgumentsIn: [productName, productPrice, productCount])
        if (result) {
            print("insert success")
        } else {
            print("insert failed")
        }
    }
    
    //更新数据库内容
    func updateProductData(in productName: String, productCount: Int) {
        let sql: String = "UPDATE product SET count = ? WHERE name = ?"
        let result: Bool = dataBase!.executeUpdate(sql, withArgumentsIn: [productCount, "hah"])
        if (result) {
            print("update success")
        } else {
            print("update failed")
        }
    }
    //删除数据库内相应的内容
    func deleteProduct(_ productName: String) {
        let sql: String = "DELETE FROM product WHERE name = ?"
        let result: Bool = dataBase!.executeUpdate(sql, withArgumentsIn: [productName])
        if (result) {
            print("delete success")
        } else {
            print("delete failed")
        }
    }
    
    //查找数据库相应的内容
    func queryDataBaseProduct() {
        let sql: String = "SELECT * FROM product WHERE count > ?"
        let resultSet: FMResultSet = dataBase!.executeQuery(sql, withArgumentsIn: [0])
        
        //遍历结果集合
        while resultSet.next() {
            print(resultSet.int(forColumn: "count"))
            print(resultSet.string(forColumn: "name"))
            print(resultSet.string(forColumn: "originalPrice"))
        }
    }
}
