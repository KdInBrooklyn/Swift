//
//  LeftModel.swift
//  购物车
//
//  Created by 李森 on 2016/12/12.
//  Copyright © 2016年 李森. All rights reserved.
//

import UIKit

class LeftModel: NSObject {
    var productName: String?
    
    //MARK: life cycle
    init(data: JSON) {
        super.init()
        
        self.productName = data["name"].stringValue
    }
    
    override init() {
        super.init()
    }
}
