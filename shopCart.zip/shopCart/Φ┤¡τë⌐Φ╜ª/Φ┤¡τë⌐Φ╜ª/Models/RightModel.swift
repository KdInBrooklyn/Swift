//
//  RightModel.swift
//  购物车
//
//  Created by 李森 on 2016/12/12.
//  Copyright © 2016年 李森. All rights reserved.
//

import UIKit

class RightModel: NSObject {
    
    var proDes: String?
    var goodDetail: [DetailModel] = [DetailModel]()
    
    
    init(data: JSON) {
        super.init()
        
        self.proDes = data["desciption"].stringValue
        if data["goods"].exists() {
            let arr = data["goods"].array
            for item in arr! {
                let detail: DetailModel = DetailModel(data: item)
                self.goodDetail.append(detail)
            }
        }
    }

    override init() {
        super.init()
    }
    
}
