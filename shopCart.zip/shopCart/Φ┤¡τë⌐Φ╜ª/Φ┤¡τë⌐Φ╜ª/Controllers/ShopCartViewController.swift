//
//  ShopCartViewController.swift
//  购物车
//
//  Created by 李森 on 2016/12/12.
//  Copyright © 2016年 李森. All rights reserved.
//

import UIKit

class ShopCartViewController: UIViewController {
    
    fileprivate lazy var leftDataSource: [LeftModel] = {
       return [LeftModel]()
    }()
    
    fileprivate lazy var rightDataSource: [RightModel] = {
        return [RightModel]()
    }()
    
    fileprivate lazy var leftTableView: UITableView = {
        let tableView: UITableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.backgroundColor = UIColor.white
        tableView.delegate = self
        tableView.dataSource = self
        
        return tableView
    }()
    
    fileprivate lazy var rightTableView: UITableView = {
        let tableView: UITableView = UITableView(frame: CGRect.zero, style: .grouped)
        tableView.backgroundColor = UIColor.white
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib.init(nibName: "RightTableViewCell", bundle: nil), forCellReuseIdentifier: "rightCell")
//        tableView.register(UIView.classForKeyedArchiver(), forHeaderFooterViewReuseIdentifier: "header")
        
        return tableView
    }()
    
    fileprivate lazy var bottomView: ShopView = {
        let view: ShopView = ShopView(frame: CGRect.zero)
        view.backgroundColor = UIColor.red
        return view
    }()
    
    //MARK: life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.loadDataFromFile()
        self.title = "Demo"
        self.view.backgroundColor = UIColor.gray
        self.initViews()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    //MARK: private function
    fileprivate func initViews() {
        self.view.addSubview(self.leftTableView)
        self.leftTableView.snp.makeConstraints { (make: ConstraintMaker) in
            make.top.equalTo(self.view.snp.top).offset(64.0)
            make.left.equalTo(self.view.snp.left)
            make.width.equalTo(100.0)
            make.height.equalTo(200.0)
        }
        
        self.view.addSubview(self.rightTableView)
        self.rightTableView.snp.makeConstraints { (make: ConstraintMaker) in
            make.top.equalTo(self.view.snp.top).offset(64.0)
            make.left.equalTo(self.leftTableView.snp.right).offset(10.0)
            make.right.equalTo(self.view.snp.right)
            make.bottom.equalTo(self.view.snp.bottom).offset(-50.0)
        }
        
        self.view.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make: ConstraintMaker) in
            make.top.equalTo(self.rightTableView.snp.bottom)
            make.bottom.left.right.equalTo(self.view)
        }
    }
    
    fileprivate func loadDataFromFile() {
        if  let path = Bundle.main.path(forResource: "goods", ofType: "json")
        {
            let fileUrl: URL = URL(fileURLWithPath: path)
            do
            {
                let fileData = try Data(contentsOf: fileUrl)
                //使用第三方SwiftyJSON来解析数据
                let JSONData = JSON(data: fileData)
                let dataArr = JSONData.array
                if let num = dataArr?.count {
                    for i in 0..<num {
                        let leftModel: LeftModel = LeftModel(data: dataArr![i])
                        self.leftDataSource.append(leftModel)
                        
                        let rightModel: RightModel = RightModel(data: dataArr![i])
                        self.rightDataSource.append(rightModel)
                    }
                }
                
                //使用系统自带的方法解析JSON数据
//                do
//                {
//                    let JSONData = try JSONSerialization.jsonObject(with: fileData, options: JSONSerialization.ReadingOptions.allowFragments) as? Array<Any>
////                    print(JSONData)
//                    
//                } catch  {
//                    print("解析过程中出现错误")
//                }
            } catch  {
                print(error.localizedDescription)
            }
        } else {
            print("文件不存在")
        }
    }
    
}

extension ShopCartViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView == self.leftTableView {
            return 1
        } else {
            return self.rightDataSource.count
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.leftTableView {
            return self.leftDataSource.count
        } else {
            return self.rightDataSource[section].goodDetail.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //左边的tableView
        if tableView == self.leftTableView
        {
            var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "cell")
            if (cell == nil)
            {
                cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
            }
            
            cell?.textLabel?.text = self.leftDataSource[indexPath.row].productName
            
            return cell!
        } else { //右边的tableView
            var cell: RightTableViewCell? = tableView.dequeueReusableCell(withIdentifier: "rightCell") as! RightTableViewCell? //之后走cell里面的awakeFromNib方法
            if (cell == nil) {
                cell = RightTableViewCell(style: .default, reuseIdentifier: "rightCell")
            }
            
            cell?.cellObject = self.rightDataSource[indexPath.section].goodDetail[indexPath.row]
            
            return cell!
        }
    }
    
    //设置tableView的头视图
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let label: UILabel = UILabel(frame: CGRect(x: 0.0, y: 0.0, width: 20, height: 30))
        label.backgroundColor = UIColor.yellow
        label.text = self.rightDataSource[section].proDes
        label.textColor = UIColor.red
        
        return label
    }
    
    //设置tableView的尾视图
//    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
//        let label = UILabel(frame: CGRect(x: 0.0, y: 0.0, width: 100.0, height: 100.0))
//        label.backgroundColor = UIColor.black
//        
//        return label
//    }
    
    //必须设置头视图的高度，否则的话当section = 0的时候无法显示其头视图
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView == leftTableView {
            return 0.0
        } else {
            return 50.0
        }
    }
    
    //返回左右两边不同tableView的cell高度
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == self.rightTableView {
            return 100
        } else {
            return 40
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if tableView == self.leftTableView {
            self.rightTableView.scrollToRow(at: IndexPath.init(item: 0, section: indexPath.row), at: UITableViewScrollPosition.top, animated: true)
        } else {
//            print("right")
            
            
        }
    }
    
    //设置cell的下划线
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.separatorInset = UIEdgeInsets.zero
        cell.preservesSuperviewLayoutMargins = false
        cell.layoutMargins = UIEdgeInsets.zero
    }
}

