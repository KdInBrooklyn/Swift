//
//  ViewController.swift
//  购物车
//
//  Created by 李森 on 2016/12/12.
//  Copyright © 2016年 李森. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    fileprivate lazy var buyButton: UIButton = {
        let button: UIButton = UIButton(frame: CGRect.zero)
        button.setTitle("Buy", for: .normal)
        button.backgroundColor = UIColor.purple
        button.addTarget(self, action: #selector(ViewController.eventBuyButtonDidClicked), for: .touchUpInside)
        
        return button
    }()
    
    fileprivate lazy var shopVC: ShopCartViewController = {
        return ShopCartViewController()
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addSubview(self.buyButton)
        self.buyButton.snp.makeConstraints { (make: ConstraintMaker) in
            make.left.equalTo(self.view.snp.left).offset(20.0)
            make.right.equalTo(self.view.snp.right).offset(-20.0)
            make.height.equalTo(30.0)
            make.bottom.equalTo(self.view.snp.bottom).offset(-30.0)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func eventBuyButtonDidClicked() {
        self.shopVC.transitioningDelegate = self
        self.modalPresentationStyle = .fullScreen //.custom
        self.present(self.shopVC, animated: true, completion: nil)
    }

}

extension ViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return FullScreenModalAnimator()
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return FullScreenModalAnimator()
    }
}
