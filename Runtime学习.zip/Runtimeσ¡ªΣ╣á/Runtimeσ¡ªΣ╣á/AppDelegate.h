//
//  AppDelegate.h
//  Runtime学习
//
//  Created by 李森 on 2017/1/6.
//  Copyright © 2017年 李森. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

